using UnityEngine;

public class Cell
{
    public char letter;

    public Color color; 

}
